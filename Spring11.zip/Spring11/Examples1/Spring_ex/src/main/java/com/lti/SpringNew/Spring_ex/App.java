package com.lti.SpringNew.Spring_ex;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
      AbstractApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
      HelloWorld bean = (HelloWorld) context.getBean("helloWorldBean");
      bean.printMessage("Hello World Spring 4");
      context.close();
    }
}
