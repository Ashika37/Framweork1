package com.lti.SpringNew.Spring_ex;

public interface HelloWorld {
	
	public void printMessage(String message);
 
}
