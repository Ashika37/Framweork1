package com.lti.SpringCollection.Collection_Example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

class CollectionMain {

	public static void main(String[] args)
{
		ApplicationContext context = new AnnotationConfigApplicationContext( CollectionConfig.class);
		CollectionBean collectionBean = context.getBean(CollectionBean.class);
		collectionBean.printNameList();
		
		CollectionBean collectionBean1 = context.getBean(CollectionBean.class);
		collectionBean1.printNameList1();
}
}
