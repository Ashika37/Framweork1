package com.lti.spring_jpa.config;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.lti.spring_jpa.JPA_EX.Person;
import com.lti.spring_jpa.config.AppConfig;
import com.lti.spring_jpa.service.PersonService;

public class App 
{
    public static void main( String[] args )
    {
       AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
       PersonService personService = context.getBean(PersonService.class);
           
       personService.add(new Person("Sachin" , "Tendulkar" , "sachintendulkar@gmail.com"));
       personService.add(new Person("David" , "Miller" , "david.miller@gmail.com"));
       personService.add(new Person("Rahul" , "Dravid" , "rahul.dravid12@gmail.com"));
       personService.add(new Person("Steven" , "Smith" , "stevensmithr@gmail.com"));
       
       List<Person> persons = personService.listPersons();
       for(Person person : persons){
    	   System.out.println("Id =" +person.getId());
    	   System.out.println("First Name =" +person.getFirstName());
    	   System.out.println("Last Name =" +person.getLastName());
    	   System.out.println("Email =" +person.getEmail());
       }
       context.close();
    }
}
