package com.lti.assign.aSSIGNMENT;

public class EmployeeDetails {
	
	 Department d;
     public void setDepartment( Department d){
   	  this.d = d;
     }
     public void salaryDetails(){
   	  d.salary();
     }
}
