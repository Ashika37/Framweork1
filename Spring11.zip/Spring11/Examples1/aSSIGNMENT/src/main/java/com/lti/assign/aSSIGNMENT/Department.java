package com.lti.assign.aSSIGNMENT;

public interface Department {
	 void salary();
}
