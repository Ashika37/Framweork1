package com.lti.assign.aSSIGNMENT;

public class Employee implements Department {
	  public void salary(){
		  System.out.println("Salary is: 10000000000000000000000");
	  }
}
