package com.lti.SpringsetterInjection.SetterInj;

public class Trainee {
	int id;
	String tname;

	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	
	private int age;
	String country;

	public Trainee( String tname, int age, String country) {
		super();
		this.tname = tname;
		this.age = age;
		this.country = country;
	}
	
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	@Override
	public String toString() {
		return "Trainee [tname=" + tname + ", age=" + age + ", country=" + country + "]";
	}
	
	

}
