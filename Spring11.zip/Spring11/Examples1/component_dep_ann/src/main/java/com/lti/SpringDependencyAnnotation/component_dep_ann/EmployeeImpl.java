package com.lti.SpringDependencyAnnotation.component_dep_ann;

public class EmployeeImpl implements Employee {
	public void showEmployeInfo(){
		System.out.println("Employee");
	}
}
