package com.lti.SpringDependencyAnnotation.component_dep_ann;

public class DeptImpl implements Department {
	public void showDepartmentInfo(){
		System.out.println("Department");
	}

}
