package com.lti.spring_jdbcEx.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.lti.Spring_jdbc.JdbcEx.Person;

@Repository
@Qualifier("personDao")
public class PersonDaoImp1 {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	public void addPerson(Person person){
		
		jdbcTemplate.update("INSERT INTO person(person_id,first_name,last_name,age) VALUES(?,?,?,?)",person.getPersonId(), person.getFirstName(), person.getLastName(), person.getAge());
		System.out.println("person aa gya!!! :)");
	}
	
	public void editPerson(Person person,int personId){
		jdbcTemplate.update("UPDATE person SET first_name = ? , last_name = ? , age =? WHERE person_id = ?", person.getFirstName(),person.getLastName(),person.getAge(),personId);
		System.out.println("Person Updated !!");
	}
	
	public void deletePerson(int personId){
		jdbcTemplate.update("DELETE from person WHERE person_id = ?" , personId);
		System.out.println("Person Deleted !!");
	}
	
	@SuppressWarnings("unchecked")
	public Person find(int personId){
		@SuppressWarnings("rawtypes")
		Person person = (Person) jdbcTemplate.queryForObject("SELECT * FROM person where person_id = ?", new Object[] {personId} , new BeanPropertyRowMapper(Person.class));
		return person;
	}
	
	@SuppressWarnings("rawtypes")
	public List < Person > findALL(){
		@SuppressWarnings("unchecked")
		List <Person > persons = jdbcTemplate.query("SELECT * FROM person", new BeanPropertyRowMapper(Person.class));
		return persons;
	}
	
}
