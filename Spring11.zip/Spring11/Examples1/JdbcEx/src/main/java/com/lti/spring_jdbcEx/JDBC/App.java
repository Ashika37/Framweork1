package com.lti.spring_jdbcEx.JDBC;

import java.util.List;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.lti.spring_jdbcEx.config.ApplicationConfig;
import com.lti.spring_jdbcEx.service.PersonService;

public class App 
{
    public static void main( String[] args )
    {
    	
    	AbstractApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
    	PersonService personService = (PersonService) context.getBean("personService");
    	
    	Person Kapil = new Person(4,"Kapil" ,"Dev" , 64);
    	Person Sachin = new Person(5,"Sachin" ,"Tendulkar" , 44);
    	Person Virat = new Person(6,"Virat" ,"Kohli" , 31);
    	
    	personService.addPerson(Kapil);
    	personService.addPerson(Sachin);
    	personService.addPerson(Virat);
    	
    	System.out.println("Find All");
    	List < Person > persons = personService.findALL();
    	for(Person person: persons){
    		System.out.println(person);
    	}
    	System.out.println("Delete person Id = 3");
    	int deleteMe = 3;
    	personService.deletePerson(deleteMe);
    	
    	Kapil.setFirstName("Kapil - Updated");
    	Kapil.setLastName("Paaji - Updated");
    	Kapil.setAge(62);
    	
    	System.out.println("Update person Id = 1");
    	int updateMe = 1;
    	personService.editPerson(Kapil, updateMe);
    	
    	System.out.println("Find person Id = 2");
    	Person person = personService.find(2);
    	System.out.println(person);
    	
    	System.out.println("Find All again ");
    	persons = personService.findALL();
    	for (Person p: persons){
    		System.out.println(p);
    	}
    	context.close();
    }
   
}
