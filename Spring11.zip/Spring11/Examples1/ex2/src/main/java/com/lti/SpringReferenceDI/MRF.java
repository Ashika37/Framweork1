package com.lti.SpringReferenceDI;

public class MRF implements Wheel{


	public void rotate(){
		
		System.out.println("Rotate");
	}
	
} 
