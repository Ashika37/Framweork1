package com.lti.SpringReferenceDI;

public interface Wheel {

	void rotate();
}
