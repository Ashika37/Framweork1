package com.lti.SpringAnnotation.Annotation_example;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfiguration {
	
	@Bean(name="countryObj")
	public Country getCountry()
	{
		return new Country("India");
	}
	
	@Bean(name="studentObj")
	public Student getStudent(){
		
		 // return new Student(countryObj1);
		return new Student( 1 ,"Ila",getCountry());
	}

}
