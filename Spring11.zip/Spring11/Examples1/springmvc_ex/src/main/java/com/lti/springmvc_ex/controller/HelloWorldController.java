package com.lti.springmvc_ex.controller;

import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.lti.springmvc_ex.model.HelloWorld;

@Controller
public class HelloWorldController {
	
	@RequestMapping("/helloworld")
	public String handler(Model model){
		
		HelloWorld helloworld = new HelloWorld();
		helloworld.setMessage("Hello world examples using spring MVC 5");
		helloworld.setDateTime(LocalDateTime.now().toString());
		model.addAttribute("helloworld",helloworld);
		return "helloworld";
	}
	
	
}
